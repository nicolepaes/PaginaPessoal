package com.programem.teste;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HabilidadesController {
    
@GetMapping("/Habilidades")
public String Habilidades(){
    return "Habilidades";
}

}